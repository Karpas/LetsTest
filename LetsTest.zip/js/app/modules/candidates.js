var Candidates = {};
Candidates.Models = {
    Link : Backbone.Model.extend({})
};

Candidates.Collection = {
    Links : Backbone.Collection.extend({
        model: Menu.Models.Link
    })
};

Candidates.Views = {
    MainView : Backbone.View.extend({
        el: $('#menu'),

        initialize: function() {
            _.bindAll(this, 'render');
            console.log("Candidates view rendered");
            this.render();
        },
        render: function () {
            var singleRecordTmpl = "/templates/candidates/candidates.html";
            window.utils.fetchTemplate(singleRecordTmpl, function (tmpl) {
                console.log(tmpl);
                /*var $newRecord = $(tmpl({
                    recordType: recordType,
                    record: record
                }));*/
            })
            
        }
    })
};
