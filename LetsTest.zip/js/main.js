(function($){
    app.router = new AppRouter();
})(jQuery);