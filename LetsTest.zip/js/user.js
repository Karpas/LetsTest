app.currentUser = {
	role: "hr"
}